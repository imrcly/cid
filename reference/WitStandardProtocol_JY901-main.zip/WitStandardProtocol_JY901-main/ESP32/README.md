# Instruction

The folder name is platform or language. Please find the corresponding folder according to your platform and programming language before using it

## ESP32_SDK Quick Start 

https://support-73.gitbook.io/witmotion-sdk/wit-standard-protocol/sdk/esp32_sdk-quick-start

# 使用说明

文件夹名称为平台或者变成语言，使用前请按照您的所属平台和和所用编程语言来找对对应的文件夹

## 说明文档

https://wit-motion.yuque.com/wumwnr/ltst03/loyuuwrk5f2bo5kg?singleDoc# 《ESP32_SDK快速上手》






