#ifndef __UART1_H
#define __UART1_H

void Usart1Init(unsigned int uiBaud);

#endif

//------------------End of File----------------------------

